import sys
import csv


def main():
    if len(sys.argv) != 3:
        print('Usage: python dna.py data.csv sequence.txt')
    else:
        print(match(sys.argv))


def match(n):
    # read the csv
    with open(n[1]) as csvfile:
        csv_content = csv.reader(csvfile, delimiter=',')
        line_count = 0
        old = []
        new = []
        # memory the csv
        for row in csv_content:
            old.append(row)
            new.append(row[1:])

    # read the text
    read_text = open(n[2], 'r')
    read_text = read_text.readlines()

    # compare the the text
    counts = []
    for sh in new[0]:
        # use the index to find the max number of STR
        ans = [0] * len(str(read_text))
        for i in range(len(str(read_text)) - len(sh), -1, -1):
            if str(read_text)[i:i + len(sh)] == sh:
                if i + len(sh) > len(str(read_text)) - 1:
                    ans[i] = 1
                else:
                    ans[i] = 1 + ans[i + len(sh)]
        counts.append(str(max(ans)))

    # find the same one
    if not(counts in new):
        return ('No match')
    else:
        index = new.index(counts)
        name = old[index][0]
        return name


main()
